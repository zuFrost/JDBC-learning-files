package com.frankmoley.lil.jdbc;

public class JDBCExecutor {

    public static void main(String... args){
        System.out.println("Hello Learning JDBC");
    }
}
