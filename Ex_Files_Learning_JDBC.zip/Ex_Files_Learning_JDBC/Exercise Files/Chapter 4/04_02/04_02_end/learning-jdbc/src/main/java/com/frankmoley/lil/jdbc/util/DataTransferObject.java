package com.frankmoley.lil.jdbc.util;

public interface DataTransferObject {

    long getId();
}
